var searchData=
[
  ['returnfilereadquestion_42',['ReturnFileReadQuestion',['../logic_8cpp.html#a7aa81c0bc7e30100888cd7904d6a1d0b',1,'ReturnFileReadQuestion():&#160;logic.cpp'],['../logic_8h.html#a7aa81c0bc7e30100888cd7904d6a1d0b',1,'ReturnFileReadQuestion():&#160;logic.cpp']]],
  ['returnmedianquestion_43',['ReturnMedianQuestion',['../logic_8cpp.html#a230112eede37eea6f74eae0902db7c9a',1,'ReturnMedianQuestion():&#160;logic.cpp'],['../logic_8h.html#a230112eede37eea6f74eae0902db7c9a',1,'ReturnMedianQuestion():&#160;logic.cpp']]]
];
