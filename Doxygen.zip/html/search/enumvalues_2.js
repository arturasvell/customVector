var searchData=
[
  ['vector_142',['VECTOR',['../logic_8h.html#a2a3c0067e44c5ef3210a256d06c16b0fa1a85ef13eaa80e8561743892f9dba958',1,'logic.h']]]
];
