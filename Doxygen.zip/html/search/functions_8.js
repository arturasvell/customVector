var searchData=
[
  ['name_95',['Name',['../class_student.html#ae8ffed3b5235e256636f1f747d171f5d',1,'Student']]]
];
