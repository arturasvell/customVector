var searchData=
[
  ['generatetxtfiles_17',['GenerateTxtFiles',['../logic_8cpp.html#a0fbb39e3e0c84e8aa1f81ca80c9a025c',1,'GenerateTxtFiles(int amountOfFiles):&#160;logic.cpp'],['../logic_8h.html#a0fbb39e3e0c84e8aa1f81ca80c9a025c',1,'GenerateTxtFiles(int amountOfFiles):&#160;logic.cpp']]],
  ['generationalgorithm_18',['GenerationAlgorithm',['../logic_8cpp.html#a2859bc2cc9c91df450622c51b8dc0073',1,'GenerationAlgorithm(int amountToGenerate, int counter):&#160;logic.cpp'],['../logic_8h.html#a2859bc2cc9c91df450622c51b8dc0073',1,'GenerationAlgorithm(int amountToGenerate, int counter):&#160;logic.cpp']]],
  ['growcounter_19',['growCounter',['../class_vec.html#a36dbb9a0c985b13059e1a6be31871040',1,'Vec']]]
];
