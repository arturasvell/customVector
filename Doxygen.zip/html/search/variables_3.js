var searchData=
[
  ['name_133',['name',['../class_person.html#a669b64897b4d823a27bb5866368d4dfa',1,'Person::name()'],['../class_student.html#a671f6b115a158653a0f0bece34ea0667',1,'Student::name()']]]
];
