var searchData=
[
  ['surname_134',['surname',['../class_person.html#a03d6fc8538ee5ee66dbc82478276c9e4',1,'Person::surname()'],['../class_student.html#a64eb0c4fb3be45c4f6ea9091bbfa4d69',1,'Student::surname()']]]
];
