var searchData=
[
  ['name_27',['name',['../class_person.html#a669b64897b4d823a27bb5866368d4dfa',1,'Person::name()'],['../class_student.html#a671f6b115a158653a0f0bece34ea0667',1,'Student::name()'],['../class_student.html#ae8ffed3b5235e256636f1f747d171f5d',1,'Student::Name()']]],
  ['namudarbainew_2ecpp_28',['namuDarbaiNew.cpp',['../namu_darbai_new_8cpp.html',1,'']]]
];
