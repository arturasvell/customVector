var searchData=
[
  ['addinfo_0',['AddInfo',['../logic_8cpp.html#a0aca216f09578c1f6f74b9d83281b296',1,'AddInfo(deque&lt; Student &gt; arr):&#160;logic.cpp'],['../logic_8h.html#a0aca216f09578c1f6f74b9d83281b296',1,'AddInfo(deque&lt; Student &gt; arr):&#160;logic.cpp']]],
  ['addinfo1_1',['AddInfo1',['../logic_8cpp.html#ab4ab9e33df5731ffdf710f3ac87cdd75',1,'AddInfo1(vector&lt; Student &gt; arr):&#160;logic.cpp'],['../logic_8h.html#ab4ab9e33df5731ffdf710f3ac87cdd75',1,'AddInfo1(vector&lt; Student &gt; arr):&#160;logic.cpp']]],
  ['addinfo2_2',['AddInfo2',['../logic_8cpp.html#a7feeb258e41c4666d64ad1ce5abc20f3',1,'AddInfo2(list&lt; Student &gt; arr):&#160;logic.cpp'],['../logic_8h.html#a7feeb258e41c4666d64ad1ce5abc20f3',1,'AddInfo2(list&lt; Student &gt; arr):&#160;logic.cpp']]]
];
