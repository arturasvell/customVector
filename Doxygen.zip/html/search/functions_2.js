var searchData=
[
  ['convertinttostring_85',['ConvertIntToString',['../logic_8cpp.html#ab5342b8233bb6e1d480722d9d2dddf2c',1,'ConvertIntToString(int toConvert):&#160;logic.cpp'],['../logic_8h.html#ab5342b8233bb6e1d480722d9d2dddf2c',1,'ConvertIntToString(int toConvert):&#160;logic.cpp']]],
  ['countaverage_86',['CountAverage',['../class_student.html#aebd2eaf06083faf780f307f9e214b94f',1,'Student']]],
  ['countfinal_87',['CountFinal',['../class_student.html#a3d06bf31e0b3b42dc8191ab610be3b64',1,'Student']]],
  ['countmedian_88',['CountMedian',['../class_student.html#aa7a092be4c90fdae548d00bba1d5afa1',1,'Student']]]
];
